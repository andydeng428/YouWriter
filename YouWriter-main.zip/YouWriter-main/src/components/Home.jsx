import React from "react";

const AboutLogin = () => {
    return <div>Home</div>;
};

export default AboutLogin;
