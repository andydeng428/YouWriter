import Navbar from "./Navbar";
import About from "./About";
import Notes from "./Notes";
import Summarize from "./Summarize";
import Home from "./Home";
import Summary from "./Summary";

export { About, Home, Navbar, Notes, Summarize, Summary };
