import logo from "./logo.svg";
import close from "./close.svg";
import menu from "./menu.svg";
import mascot from "./mascot.png";
import arrow from "./arrow.svg";

export { close, logo, menu, mascot, arrow };
